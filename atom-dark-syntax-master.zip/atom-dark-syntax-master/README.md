### This package is now a part of the [core Atom repository](https://github.com/atom/atom/tree/master/packages/atom-dark-syntax), please direct all issues and pull requests there in the future!

---

# Atom Dark Syntax theme

A dark syntax theme for Atom.

This theme is installed by default with Atom and can be activated by going to
the _Themes_ section in the Settings view (`cmd-,`) and selecting it from the
_Syntax Themes_ dropdown menu.

![](https://f.cloud.github.com/assets/671378/2264549/f49e9bf2-9e73-11e3-9329-e2d59dd1b119.png)
